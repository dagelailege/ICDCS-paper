import pymongo
import dateutil.parser
import codecs
import re
from time import time
import os
import pandas as pd
import numpy as np
import math
import smopy
import matplotlib.pyplot as plt
import matplotlib
from mpl_toolkits.basemap import Basemap
import copy
from mpl_toolkits.mplot3d import Axes3D

def get_map_size(filepath ="./map_orginal.npy" ):
    map_array_reversal = np.load(filepath)
    map_array = np.zeros((region_acc,region_acc))
    for i in range(region_acc):
        for j in range(region_acc):
            map_array[i][j] = map_array_reversal[region_acc-i-1][j]
    amin, amax = map_array.min(), map_array.max()
    map_array = (map_array-amin)/(amax-amin)
    return map_array
def array_enlarge(data_arr):

    re = np.zeros((632,613))
    for i in range(632):
        for j in range(613):
            r = (int) (i/15.8)
            c = (int) (j/15.325)
            re[i][j] = data_arr[r][c]
    """
    re = np.zeros((623,642))
    for i in range(623):
        for j in range(642):
            r = (int) (i/15.575)
            c = (int) (j/16.05)
            re[i][j] = data_arr[r][c]
    """
    #return re
    return re
#每五分钟画一张图片
#北京四环经纬度
#左上：39.9866,116.2652 右上：39.9866,116.4839   左下：39.8270,116.2652    右下：39.8270,116.4839
#纬度start:39.9866    end:39.8270    方向：从上到下，从大到小    分40个格子split:0.00399
#精度start:116.2652     end:116.4838      方向：从左到右，小到大   分40个格子split:0.005465
start_time = 1472659200  #20160902 00:00:00转化为UNIX时间戳,单位是秒   28466
split = 120
max_latitude = 39.9966*100000
max_longitude = 116.4939*100000
min_latitude = 39.8270*100000
min_longitude = 116.2652*100000
shf_path1 = 'F:/gradute_student_2017/Vnet/ICDCS/bj_shp/高速公路s_polyline'
shf_path2 = 'F:/gradute_student_2017/Vnet/ICDCS/bj_shp/市区道路_polyline'
cmap = plt.get_cmap('Accent')
region_acc = 40        #划分为个region_acc*region_acc个格子

offset = 0
lat_split = (max_latitude-min_latitude)/region_acc
lon_split = (max_longitude-min_longitude)/region_acc
slots = ["199","227","425","536","632","687"]

#matplotlib.rcParams['fontsize'] = 12
for slot in ["89"]:

    #car_optimize = np.load("./optimize_20160903/241_optimize_solution.npy")
    #print (car_optimize.shape)
    #car_optimize = car_optimize.reshape((region_acc,8,region_acc))
    #data_path =  "F:/gradute_student_2017/Vnet/ICDCS/data_pre_handle/car_flow_np_20160920/{}_in_flow.npy".format(slot)
    #car_in_flow = np.load(data_path)
    map_arr = get_map_size()
    #car_in_flow = np.load("./car_flow_np_20160903/{}_in_flow.npy".format(slot))
    #car_in_flow = np.load("./car_nflow_np_20160901/{}_in_nflow_new.npy".format(slot-1))
    #one_neigbor_op = car_optimize[:,slot,:]
    #print (one_neigbor_op[0][0],one_neigbor_op[0][39])
    #exit()
    #one_neigbor_op[one_neigbor_op<0] = 0
    fig = plt.figure(figsize=(12,8))
    m = Basemap(llcrnrlon=min_longitude/100000, llcrnrlat=min_latitude/100000, urcrnrlon=max_longitude/100000, urcrnrlat=max_latitude/100000,projection='stere',lat_0=min_latitude/100000,lon_0=min_longitude/100000,width = 400, height = 400)
    #readshapefile耗费大量的时间
    m.readshapefile(shf_path1,'roads',color='black', linewidth = 1)
    m.readshapefile(shf_path2,'roads',color = 'black')
    #lons, lats, x, y = m.makegrid(region_acc, region_acc, returnxy=True)
    lons, lats, x, y = m.makegrid(613, 632, returnxy=True)
    #print (lons[0][0],lats[0][0])
    #car_in_flow = array_enlarge(car_in_flow)
    map_arr = array_enlarge(map_arr)
    levels=[0,10,20,30,40,50,60,70]
    cs = m.pcolor(x,y,map_arr)
    cs.set_cmap(cmap)

    cbar = m.colorbar(cs,location='right',pad="5%")
    #cbar.set_label('car_in_flow')
    plt.savefig('./map_size.png')


    """
    font = {
        'size'   : 12}
    matplotlib.rc('font', **font)
    fig = plt.figure(figsize=(12,8))
    ax = Axes3D(fig)
    #img = read_png("./road.png")
    #print (img.shape)
    #imgX, imgY = np.ogrid[0:img.shape[0], 0:img.shape[1]]
    inflow = array_enlarge(car_in_flow)
    #inflow = car_in_flow
    print (inflow.shape)
    X = np.arange(0, 642, 1)
    Y = np.arange(0, 623, 1)
    X, Y = np.meshgrid(X, Y)
    Z = inflow#
    #Z3 = np.zeros(imgX.shape)

    # 具体函数方法可用 help(function) 查看，如：help(ax.plot_surface)

    surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=plt.get_cmap("YlOrRd"), vmin = 0,vmax = 70)
    ax.set_zlim(0, 200)
    #new_ticks = np.linspace(0, 642, 5)
    plt.xticks([0,155.75,311.5,467.25,623],[0,10,20,30,40])
    plt.yticks([0,160.5,321,481.5,642],[0,10,20,30,40])
    #plt.yticks(new_ticks)
    #surf2 = ax.plot_surface(X, Y, Z2, rstride=1, cstride=1, cmap=plt.get_cmap("cool"),vmin = 200,vmax = 225)
    fig.colorbar(surf, shrink=0.3, aspect=10)
    #fig.colorbar(surf2, shrink=0.3, aspect=10)
    #plt.show()
    plt.savefig("./image_modify2/{}_3D.png".format(slot))
    plt.close()
    #plt.savefig('F:/gradute_student_2017/Vnet/ICDCS/data_pre_handle/car_flow_image_test/map_gray_3.png', bbox_inches="tight", pad_inches=0)
    """
    """
    m = Basemap(llcrnrlon=min_longitude/100000, llcrnrlat=min_latitude/100000, urcrnrlon=max_longitude/100000, urcrnrlat=max_latitude/100000,projection='stere',lat_0=min_latitude/100000,lon_0=min_longitude/100000)
    m.readshapefile(shf_path1,'roads',color='black',linewidth =1)
    m.readshapefile(shf_path2,'roads',color = 'black')
    lons, lats, x, y = m.makegrid(region_acc, region_acc, returnxy=True)
    #print (lons[0][0],lats[0][0])
    cs = m.contourf(x,y,car_out_flow)
    cs.set_cmap(cmap)
    cbar = m.colorbar(cs,location='bottom',pad="5%")
    cbar.set_label('car_out_flow')
    plt.savefig('F:/gradute_student_2017/Vnet/ICDCS/data_pre_handle/car_flow_image_test/{}_out_flow_old.png'.format(slot-1))
    """
    plt.close('all')
