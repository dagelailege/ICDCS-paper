import pymongo
import dateutil.parser
import codecs
import re
from time import time
import os
import pandas as pd
import numpy as np
import math
import smopy
import matplotlib.pyplot as plt
import matplotlib
from mpl_toolkits.basemap import Basemap
import copy
from mpl_toolkits.mplot3d import Axes3D

def array_enlarge(data_arr):                       #将40*40放大为623*642的数组，消除图片的偏差

    re = np.zeros((623,642))
    for i in range(623):
        for j in range(642):
            r = (int) (i/15.575)
            c = (int) (j/16.05)
            re[i][j] = data_arr[r][c]
    return re

slots = ["225"]

for slot in slots:

    #设置图片的字体
    font = {
        'size'   : 12}
    matplotlib.rc('font', **font)
    fig = plt.figure(figsize=(12,8))
    ax = Axes3D(fig)
    #获取数据矩阵并放大成623*642二维数组
    car_in_flow = np.load("./compare_data/26_{}_raw.npy".format(slot))
    can_not_dis = np.load("./compare_data/26_{}_nn.npy".format(slot))
    inflow = array_enlarge(car_in_flow)
    can_not_dis = array_enlarge(can_not_dis)
    #划分网格
    X = np.arange(0, 642, 1)
    Y = np.arange(0, 623, 1)
    X, Y = np.meshgrid(X, Y)
    #定义要画的两个表面，Z为交通态势图，Z2为不能分担的分布
    Z = inflow#
    Z2 = 200+can_not_dis

    #设定Z轴范围
    ax.set_zlim(0, 200)
    #设定替换X轴和Y轴刻度
    plt.xticks([0,155.75,311.5,467.25,623],[0,10,20,30,40])
    plt.yticks([0,160.5,321,481.5,642],[0,10,20,30,40])
    #画表面，Vmin,vmax定义表面最大值最小值，自己指定方便统一刻度，默认会自动取
    surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=plt.get_cmap("YlOrRd"), vmin = 0,vmax = 25)
    surf2 = ax.plot_surface(X, Y, Z2, rstride=1, cstride=1, cmap=plt.get_cmap("cool"),vmin = 200,vmax = 225)
    #画颜色bar
    fig.colorbar(surf, shrink=0.3, aspect=10)
    fig.colorbar(surf2, shrink=0.3, aspect=10)
    #plt.show()
    #保存图片
    plt.savefig("test_3D.png".format(slot))
    plt.close()
 
