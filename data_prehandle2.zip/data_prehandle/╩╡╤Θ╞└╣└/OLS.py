
# coding: utf-8

# In[1]:


#-*- coding:utf-8 -*-
import numpy as np
import os
import sklearn

from sklearn import datasets, linear_model
from sklearn.linear_model import LinearRegression
from sklearn.externals import joblib
from sklearn.metrics import mean_squared_error

# In[3]:


class ols_model(object):

    def __init__(self):
        self.linreg = LinearRegression()

    def train(self, x_s, y_s):
        self.linreg.fit(x_s, y_s)

    def pred(self, x_test):
        return self.linreg.predict(x_test)

    def serialization(self):
        joblib.dump(self.linreg, "./model/lr.pkl")

    def deserialization(self):
        self.linreg = joblib.load("./model/lr.pkl")

def get_train_data(basepath = "."):
    train_x = []
    train_y = []
    dates = ["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25"]
    num = 0
    for i in range(720*25-2):
        date_f = int(i/720)
        slot_f = int(i%720)
        date_s = int((i+1)/720)
        slot_s = int((i+1)%720)
        date_t = int((i+2)/720)
        slot_t = int((i+2)%720)
        x = np.zeros((4,40,40))
        y = np.zeros((2,40,40))
        x[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[date_f], slot_f)).reshape((40,40))
        x[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[date_f], slot_f)).reshape((40,40))
        x[2] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[date_s], slot_s)).reshape((40,40))
        x[3] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[date_s], slot_s)).reshape((40,40))
        y[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[date_t], slot_t)).reshape((40,40))
        y[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[date_t], slot_t)).reshape((40,40))
        x = x.reshape(-1)
        y = y.reshape(-1)
        train_x.append(x)
        train_y.append(y)             #y为对应的序列号
        num += 1
        if num%720==0:
            print (num)
    #print (train_x.count,train_y.count)
    return train_x,train_y
def test_data(inx,basepath = "."):
    test_x = []
    test_y = []
    dates = ["26","27","28","29","30"]
    num = 0
    for i in range(720-2):
        slot_f = i
        slot_s = i+1
        slot_t = i+2
        x = np.zeros((4,40,40))
        y = np.zeros((2,40,40))
        x[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[inx], slot_f)).reshape((40,40))
        x[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[inx], slot_f)).reshape((40,40))
        x[2] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[inx], slot_s)).reshape((40,40))
        x[3] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[inx], slot_s)).reshape((40,40))
        y[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[inx], slot_t)).reshape((40,40))
        y[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[inx], slot_t)).reshape((40,40))
        x = x.reshape(-1)
        y = y.reshape(-1)
        test_x.append(x)
        test_y.append(y)             #y为对应的序列号
        num += 1
    return test_x, test_y
# In[1]:
ols = ols_model()
#train_x, train_y = get_train_data()
#model_ols.train(train_x, train_y)
#model_ols.serialization()
ols.deserialization()
for i in range(5):
    test_x, test_y = test_data(inx=i)
    pre = ols.pred(test_x)
    tru = test_y
    pre = np.array(pre)
    pre = pre.reshape(718,2,40,40);
    path1 = "./OLS_18_35.txt"
    path2 = "./OLS_18_36.txt"
    path3 = "./OLS_18_37.txt"
    path4 = "./OLS_18_38.txt"
    path5 = "./OLS_18_39.txt"
    with open(path1,"a") as f:
        for ele in pre[:,0,18,35]:
            f.write(str(float(ele))+"\n")
    with open(path2,"a") as f:
        for ele in pre[:,0,18,36]:
            f.write(str(float(ele))+"\n")
    with open(path3,"a") as f:
        for ele in pre[:,0,18,37]:
            f.write(str(float(ele))+"\n")
    with open(path4,"a") as f:
        for ele in pre[:,0,18,38]:
            f.write(str(float(ele))+"\n")
    with open(path5,"a") as f:
        for ele in pre[:,0,18,39]:
            f.write(str(float(ele))+"\n")
    print ("finish {}".format(i))
    #print (mean_squared_error(pre, tru))
