
# coding: utf-8

# In[1]:


#-*- coding:utf-8 -*-
import numpy as np
import os
import pandas as pd
import sklearn

from sklearn import neighbors
from sklearn.cross_validation import train_test_split
from sklearn.externals import joblib
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error



# In[3]:


class knn_model(object):

    def __init__(self):
        n_neighbors = 5
        self.knn = neighbors.KNeighborsClassifier(n_neighbors,weights='uniform',algorithm='auto', n_jobs=-1)

    def train(self, x_s, y_s):
        self.knn.fit(x_s, y_s)

    def pred(self, x_test):
        return self.knn.predict(x_test)

    def serialization(self):
        joblib.dump(self.knn, "./model/knn.pkl")

    def deserialization(self):
        self.knn = joblib.load("./model/knn.pkl")


def get_train_data(basepath = "."):
    train_x = []
    train_y = []
    dates = ["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25"]
    num = 0
    for i in range(720*25-2):
        date_f = int(i/720)
        slot_f = int(i%720)
        date_s = int((i+1)/720)
        slot_s = int((i+1)%720)
        date_t = int((i+2)/720)
        slot_t = int((i+2)%720)
        x = np.zeros((4,40,40))
        y = np.zeros((2,40,40))
        x[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[date_f], slot_f)).reshape((40,40))
        x[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[date_f], slot_f)).reshape((40,40))
        x[2] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[date_s], slot_s)).reshape((40,40))
        x[3] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[date_s], slot_s)).reshape((40,40))
        y[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[date_t], slot_t)).reshape((40,40))
        y[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[date_t], slot_t)).reshape((40,40))
        x = x.reshape(-1)
        y = y.reshape(-1)
        train_x.append(x)
        train_y.append(y)             #y为对应的序列号
        num += 1
        if num%720==0:
            print (num)
    #print (train_x.count,train_y.count)
    return train_x,train_y
def test_data(inx,basepath = "."):
    test_x = []
    test_y = []
    dates = ["26","27","28","29","30"]
    num = 0
    for i in range(720-2):
        slot_f = i
        slot_s = i+1
        slot_t = i+2
        x = np.zeros((4,40,40))
        y = np.zeros((2,40,40))
        x[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[inx], slot_f)).reshape((40,40))
        x[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[inx], slot_f)).reshape((40,40))
        x[2] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[inx], slot_s)).reshape((40,40))
        x[3] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[inx], slot_s)).reshape((40,40))
        y[0] = np.load("{}/car_flow_np_201609{}/{}_in_flow.npy".format(basepath, dates[inx], slot_t)).reshape((40,40))
        y[1] = np.load("{}/car_flow_np_201609{}/{}_out_flow.npy".format(basepath, dates[inx], slot_t)).reshape((40,40))
        x = x.reshape(-1)
        y = y.reshape(-1)
        test_x.append(x)
        test_y.append(y)             #y为对应的序列号
        num += 1
    return test_x, test_y
knn = knn_model()
#train_x, train_y = get_train_data()
#print (train_y)
#knn.train(train_x,train_y)
#knn.serialization()
knn.deserialization()
for i in range(5):
    test_x, test_y = test_data(inx=i)
    pre = knn.pred(test_x)
    tru = test_y
    pre = np.array(pre)
    pre = pre.reshape(718,2,40,40);
    path = "./knn_18_39.txt"
    with open(path,"a") as f:
        for ele in pre[:,0,18,39]:
            f.write(str(float(ele))+"\n")
    print ("finish {}".format(i))
    #np.savetxt("./knn_18_5.txt",tru[:,0,18,35])
    #print (mean_squared_error(pre, tru))
#print (train_y)
