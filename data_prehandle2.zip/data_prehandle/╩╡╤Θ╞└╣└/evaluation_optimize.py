import numpy as np
import pandas as pd
import pickle


region_acc = 40
#get image and convert to the size of map data to be download of each region
def get_map_size(filepath ="./map_orginal.npy" ):
    map_array_reversal = np.load(filepath)
    map_array = np.zeros((region_acc,region_acc))
    for i in range(region_acc):
        for j in range(region_acc):
            map_array[i][j] = map_array_reversal[region_acc-i-1][j]
    amin, amax = map_array.min(), map_array.max()
    map_array = (map_array-amin)/(amax-amin)
    return map_array
"""
返回值：归一化之后的像素值乘以车流量得到的需要下载的数据，需要下载的数据中的0.8分位数
"""

def get_data_size(inflow_path = "./car_flow_np_20160903/240_in_flow.npy", map_array = get_map_size()):
    inflow_array = np.load(inflow_path)
    data_array = map_array*inflow_array
    cont1 = np.percentile(data_array,80)        #要下载的数据大小取0.8分位数，保证80%的区域自己就能完成数据下发任务
    return data_array, cont1

"""
data_array:每个区域当前要下发的数据量
x:优化方案
cont1:基站本身数据下发能力
"""
def leftdata_withop(data_array, x,cont1):
    result = 0
    detail = np.zeros((40,40))
    for i in range(region_acc):
        for j in range(region_acc):
            fcont1 = data_array[i][j]
            fout = (x[i][j][0] if j!=0 else 0) \
                + (x[i][j][1] if i!=0 else 0) \
                + (x[i][j][2] if j!=region_acc-1 else 0) \
                + (x[i][j][3] if i!=region_acc-1 else 0) \
                + (x[i][j][4] if i!=0 and j!=0 else 0) \
                + (x[i][j][5] if i!=region_acc-1 and j!=0 else 0) \
                + (x[i][j][6] if i!=0 and j!=region_acc-1 else 0) \
                + (x[i][j][7] if i!=region_acc-1 and j!=region_acc-1 else 0)
            fin = (x[i][j+1][0] if j<(region_acc-1) else 0) \
                + (x[i+1][j+1][4] if j<(region_acc-1) and i<(region_acc-1) else 0)\
                + (x[i+1][j][1] if i<(region_acc-1) else 0)\
                + (x[i+1][j-1][6] if i<(region_acc-1) and j>0 else 0)\
                + (x[i][j-1][2] if j>0 else 0)\
                + (x[i-1][j-1][7] if i>0 and j>0 else 0)\
                + (x[i-1][j][3] if i>0 else 0)\
                + (x[i-1][j+1][5] if i>0 and j<(region_acc-1) else 0)
            fcont2 = cont1
            temp = max(0,fcont1 +fin - fout - fcont2)
            result+= temp
            detail[i][j] = temp
    return result, detail
def leftdata_withoutop(data_array,cont1):
    result = 0
    detail = np.zeros((40,40))
    for i in range(region_acc):
        for j in range(region_acc):
            if data_array[i][j] > cont1:
                result += data_array[i][j] - cont1
                detail[i][j] = data_array[i][j] - cont1
    return result, detail

"""
第一个数组是当前时间片原本每个区域需要下载的数据大小
第二个数数组是最优化的结果，
第三个数组是神经网络的结果
"""

def evaluation():
    map_array = get_map_size()
    _,cont1= get_data_size(map_array = map_array)
    dates = ["26"]
    slots = ["169","240","345","388","500","596","646"]
    result1 = []  #无优化
    result2 = []   #最优化
    result3 = []    #神经网络优化

    with open("./p3ResultDict_pred_yval.data",'rb') as f:
        data = pickle.load(f)
    num = 0
    for date in dates:
        #before 优化之前不能下发的数据量
        for slot in range(2,720):
            inflow_path = "./car_flow_np_201609{}/{}_in_flow.npy".format(date,slot)
            data_array, _= get_data_size(inflow_path = inflow_path,map_array = map_array)
            nn_array = data["pred"][num]
            op_array = data["yval"][num]
            #print (len(data["yval"]))
            #print (leftdata_withoutop(data_array,cont1),leftdata_withop(data_array,op_array,cont1),leftdata_withop(data_array,nn_array,cont1))
            #result1.append(leftdata_withoutop(data_array,cont1))
            #result,detail = leftdata_withop(data_array,op_array,cont1)
            #result2.append(result)
            #result,detail = leftdata_withop(data_array,nn_array,cont1)
            #np.save("./python_3D_figure/cannot_dis_data/{}_{}.npy".format(date,slot),detail)
            #result3.append(result)
            """
            if slot%100==0:
                np.save("./eva_result/data_cannot_dis/{}_{}.npy".format(date,slot),detail)
            """
            result1,detail1 = leftdata_withoutop(data_array,cont1)
            result2,detail2 = leftdata_withop(data_array,nn_array,cont1)
            if (result1-result2)>0.4*result1 and result1>1500:
                np.save("./python_3D_figure/cannot_dis_data/26_{}_nn.npy".format(slot),detail2)
                np.save("./python_3D_figure/cannot_dis_data/26_{}_raw.npy".format(slot),detail1)

            #np.save("./python_3D_figure/cannot_dis_data/{}_{}_nn.npy".format(date,slot),detail)
            num += 1

    #data = {"raw":result1,"op":result2,"nn":result3}
    #df = pd.DataFrame(data = data)
    #df.to_csv("./eva_result/temp3.csv",index=False)
evaluation()
