#coding=utf-8  
import numpy as np
from cvxpy import *
import numpy
from PIL import Image
import time




#get Problem data.
region_acc = 40
date = "03"
#get image and convert to the size of map data to be download of each region
def get_map_size(filepath ="./map_orginal.npy" ):
    map_array_reversal = np.load(filepath)
    map_array = np.zeros((region_acc,region_acc))
    for i in range(region_acc):
        for j in range(region_acc):
            map_array[i][j] = map_array_reversal[region_acc-i-1][j]
    amin, amax = map_array.min(), map_array.max()
    map_array = (map_array-amin)/(amax-amin)
    return map_array

#根据上面求出的像素值的比例和每个格子的inflow求总的需要下传的数据量,和80%分位数的那个格子的下载速度
"""
返回值：归一化之后的像素值乘以车流量得到的需要下载的数据，需要下载的数据中的0.8分位数
"""
def get_data_size(inflow_path = "./car_flow_np_20160903/240_in_flow.npy".format(date), map_array = get_map_size()):               #修改1
    inflow_array = np.load(inflow_path)
    data_array = map_array*inflow_array
    cont1 = np.percentile(data_array,80)        #要下载的数据大小取0.8分位数，保证80%的区域自己就能完成数据下发任务
    return data_array, cont1
#根据向相邻区域的车流信息，获取每个区域的向相邻区域缓存的流量的上限，多了没用，车也下载不了那么多
def get_constrains(ninflow_path = "./car_nflow_np_201609{}/240_out_nflow.npy".format(date), map_array = get_map_size()):              #修改2
    ninflow_array = np.load(ninflow_path)
    ninflow_array.reshape((region_acc,region_acc,8,2))
    constrains_array = np.zeros((region_acc,region_acc,8))
    for i in range(region_acc):
        for j in range(region_acc):
            for k in range(8):
                #print (ninflow_array[i][j][k],map_array[i][j])
                constrains_array[i][j][k] = ninflow_array[i][j][k][0] * map_array[i][j]
    return constrains_array

def before_opt(data_array, cont1):
    count = 0
    for i in range(region_acc):
        for j in range(region_acc):
            if data_array[i][j] > cont1:
                count += data_array[i][j] - cont1
    return count

#map_aray不会变
map_array = get_map_size()
_,cont1= get_data_size(map_array = map_array)
#cont1每天的不会变，取8点的那个0.8分位数,data_array和每个时刻有关系， constrains也和每个时刻有关系
for slot in range(483,500):
    inflow_path = "./car_flow_np_201609{}/{}_in_flow.npy".format(date,slot)                                      #修改3
    ninflow_path = "./car_nflow_np_201609{}/{}_out_nflow.npy".format(date,slot)                                    #修改4
    #time1 = time.time()
    data_array, _= get_data_size(inflow_path = inflow_path,map_array = map_array)
    constrains_array = get_constrains(ninflow_path = ninflow_path,map_array = map_array)
    #time2 = time.time()
    #print ("get data_array and constrains_array past time:{}".format(time2-time1))
    # Construct the problem.
    x = Variable(region_acc,region_acc*8)
    expressions = []
    constrains = []

    """
    for i in range(region_acc):
        for j in range(region_acc):
            t = pos(x[i,j])
            expressions += [t]
    """
    for i in range(region_acc):
        for j in range(region_acc):
            fcont1 = data_array[i][j]              #自己本身有多少车要来，然后需要下传的数据大小
            #fout自己缓存给别人的数据量,fin别人缓存给自己的数据量
            fout = (x[i,j*8+0] if j!=0 else 0) \
                + (x[i,j*8+1] if i!=0 else 0) \
                + (x[i,j*8+2] if j!=region_acc-1 else 0) \
                + (x[i,j*8+3] if i!=region_acc-1 else 0) \
                + (x[i,j*8+4] if i!=0 and j!=0 else 0) \
                + (x[i,j*8+5] if i!=region_acc-1 and j!=0 else 0) \
                + (x[i,j*8+6] if i!=0 and j!=region_acc-1 else 0) \
                + (x[i,j*8+7] if i!=region_acc-1 and j!=region_acc-1 else 0)
            fin =  (x[i,(j+1)*8+0] if j<(region_acc-1) else 0) \
                + (x[i+1,(j+1)*8+4] if j<(region_acc-1) and i<(region_acc-1) else 0)\
                + (x[i+1,j*8+1] if i<(region_acc-1) else 0)\
                + (x[i+1,(j-1)*8+6] if i<(region_acc-1) and j>0 else 0)\
                + (x[i,(j-1)*8+2] if j>0 else 0)\
                + (x[i-1,(j-1)*8+7] if i>0 and j>0 else 0)\
                + (x[i-1,j*8+3] if i>0 else 0)\
                + (x[i-1,(j+1)*8+5] if i>0 and j<(region_acc-1) else 0)
            fcont2 = cont1                       #基站本身的数据下传能力
            f = pos(fcont1 +fin - fout - fcont2)           #pos(x)作用相当于max{0,x}
            expressions += [f]
    regular = 0
    for i in range(region_acc):
        for j in range(region_acc*8):
            #constrains.append(-2 <= x[i,j])
            #constrains.append(x[i,j] <= 1)
            #print (int(j/8),j%8)
            constrains += [0 <= x[i,j],x[i,j] <= constrains_array[i][int(j/8)][j%8]]
            regular += x[i,j]
    #print (type(constrains))
    expressions += [0.01*regular]
    #time3 = time.time()
    #print ("get expressions and constrains past time:{}".format(time3-time2))
    #print (type(constrains))
    #print (isinstance(constrains, list))
    objective = Minimize(sum(expressions))
    #time5 = time.time()
    #print ("get objective past time:{}".format(time5-time3))
    prob = Problem(objective, constrains)
    #print ("get prob past time:{}".format(time6-time5))
	
    # The optimal objective is returned by prob.solve().
    result = prob.solve()
    # The optimal value for x is stored in x.value.
    print ((x.value).max(),(x.value).min())
    """
    value_count = 0
    for i in range(region_acc):
        for j in range(region_acc):
            if np.array(x.value)[i][j]>0.5 :
                value_count += 1
    print (value_count)
    """


    # The optimal Lagrange multiplier for a constraint
    # is stored in constraint.dual_value.
    #print (constraints[0].dual_value)
    #print (result, before_opt(data_array, cont1))
    x_array = np.array(x.value)
    print (result - 0.01*x_array.sum(), before_opt(data_array, cont1))
    np.save("./optimize_201609{}/{}_optimize_solution.npy".format(date,slot),x_array)              #修改5
    print ("fininshed {}".format(slot))
    del data_array
    del x
    del x_array
    del constrains_array
    del expressions
    del constrains
    del objective, prob, result
    del regular
