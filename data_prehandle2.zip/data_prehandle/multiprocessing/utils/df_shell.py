#!/usr/bin/env python
# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
封装常用的shell操作

Authors: huabo (daijun), caodaijun@baidu.com
Date: 2014/12/04 14:11:02
"""


import os
import time
import uuid
import shlex
import subprocess
import shutil
import stat


def execute(cmd):
    """执行shell命令
    Args:
        cmd 需要执行的命令，不支持|管道, 不支持重定向
    Return:
        (True,  命令的返回结果)
        (False, 错误的原因)
    """
    temp_file = os.path.join("/tmp", str(uuid.uuid1()))
    fp = file(temp_file, "w")
    p = subprocess.Popen(shlex.split(cmd), stdout=fp, stderr=subprocess.STDOUT)
    exit_code = p.wait()
    fp.close()
    msg = file_get_contents(temp_file)
    remove_file(temp_file)
    return (exit_code == 0, msg.strip())


def calculate_size(path):
    """计算路径下所有文件的大小
    Args:
        path 合法的文件夹路径或文件路径
    Return:
        大小
    """
    if not os.path.exists(path):
        return 0
    status = os.stat(path)
    if stat.S_ISREG(status.st_mode):
        return status.st_size
    elif stat.S_ISDIR(status.st_mode):
        size = 0
        for f in os.listdir(path):
            sub_path = os.path.join(path, f)
            size = size + calculate_size(sub_path)
        return size
    return 0


def calculate_line(path):
    """计算路径下所有文件的行数
    Args:
        path 合法的文件夹路径或文件路径
    Return:
        行数
    """
    if not os.path.exists(path):
        return 0
    status = os.stat(path)
    if stat.S_ISREG(status.st_mode):
        (success, msg) = execute("wc -l '%s'" % path)
        return int(msg.split(' ')[0]) if success else 0 
    elif stat.S_ISDIR(status.st_mode):
        line = 0
        for f in os.listdir(path):
            sub_path = os.path.join(path, f)
            line = line + calculate_line(sub_path)
        return line
    return 0


def merge_path_to_file(src, dst):
    """将文件夹下的内容，合并到一个文件中
    Args:
        src 合法的文件夹路径或文件路径
        dst 合法的文件路径
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    if not os.path.exists(src):
        return (False, "%s not exist" % src)

    status = os.stat(src)
    if stat.S_ISREG(status.st_mode):
        return merge_file(src, dst)
    elif stat.S_ISDIR(status.st_mode):
        for f in os.listdir(src):
            src_sub_path = os.path.join(src, f)
            (success, msg) = merge_path_to_file(src_sub_path, dst)
            if not success:
                return (False, msg)
    return (True, None)


def create_dir(path):
    """创建目录，作用类似于mkdir -p
    Args:
        path 合法的文件夹路径
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    try:
        os.makedirs(path)
        return (True, None)
    except OSError as e:
        return (False, e)


def create_file(path):
    """创建空文件
    Args:
        path 合法的文件路径
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    return execute("touch %s" % path)


def remove_dir(path):
    """删除目录
    Args:
        path 合法的文件夹路径
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    try:
        shutil.rmtree(path)
        return (True, None)
    except Exception as e:
        return (False, e)


def remove_file(path):
    """删除文件
    Args:
        path 合法的文件路径
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    try:
        os.remove(path)
        return (True, None)
    except OSError as e:
        return (False, e)


def move_file(src, dst):
    """移动文件
    Args:
        src 合法的文件路径
        dst 合法的文件夹路径或文件路径
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    try:
        shutil.move(src, dst)
        return (True, None)
    except Exception as e:
        return (False, e)


def copy_file(src, dst):
    """复制文件
    Args:
        src 合法的文件路径
        dst 合法的文件夹路径或文件路径
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    try:
        shutil.copy2(src, dst)
        return (True, None)
    except Exception as e:
        return (False, e)


def merge_file(src, dst):
    """合并两个文件, 将src的文件内容追加到dst后面
    Args:
        src 合法的文件名，其内容会被追加到dst后面，不存在将报错
        dst 合法的文件名，如果该文件不存在，则将被创建，此时函数功能等于复制
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    if not os.path.exists(src):
        return (False, "file %s not exist" % src)

    buffer_size = 1024 * 1024 * 256
    try:
        with open(dst, "ab") as dst_fp:
            with open(src, "rb") as src_fp:
                while True:
                    buf = src_fp.read(buffer_size)
                    if len(buf) > 0:
                        dst_fp.write(buf)
                    else:
                        break
        return (True, None)
    except OSError as e:
        return (False, e)


def md5file_diff(path1, path2):
    """diff两个md5文件
    Args:
        path1,path2分别是两个md5文件，文件中有且只有一行内容，前32个字符是md5字符串
    Return:
        (True,  None)
        (False, 错误的原因)
    """

    if not os.path.exists(path1):
        return (False, "%s not exist" % path1)

    if not os.path.exists(path2):
        return (False, "%s not exist" % path2)

    path1_content = None
    try:
        path1_content = open(path1).read(32)
    except OSError as e:
        return (False, "read %s error, err:%s" % (path1, e.strerror))

    path2_content = None
    try:
        path2_content = open(path2).read(32)
    except OSError as e:
        return (False, "read %s error, err:%s" % (path2, e.strerror))

    if path1_content != path2_content:
        return (False, "md5 value not match, value:%s|%s" % (path1_content, path2_content))

    return (True, None)


def gen_md5(src, dst_md5file):
    """为src文件生成md5值，并保存在dst_md5file中
    Args:
        src, 需要计算md5值的源文件
        dst_md5file, 保存md5值的文件
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    (success, msg) = execute("md5sum '%s'" % src)
    if not success:
        return (False, msg)
    return file_put_contents(dst_md5file, msg)


def file_get_mtime(path):
    """获取文件的mtime，并以unix时间戳的格式返回
    Args:
        path 合法的文件夹路径或文件路径
    Return:
        mtime unix时间戳
    """
    if not os.path.exists(path):
        return 0
    try:
        return int(os.path.getmtime(path))
    except Exception as e:
        return 0


def file_get_contents(path):
    """获取文件的内容
    Args:
        path 合法的文件夹路径或文件路径
    Return:
        文件的内容
    """
    content = None
    if not os.path.exists(path):
        return None
    with open(path) as fp:
        return fp.read()


def file_put_contents(path, content, mode="w"):
    """将一段内容写入到文件
    Args:
        path 合法的文件夹路径或文件路径
        content 需要写入到文件的内容
        mode 写入模式，参考open的mode参数
    Return:
        (True,  None)
        (False, 错误的原因)
    """
    try:
        with open(path, mode) as fp:
            fp.write(content)
        return (True, None)
    except OSError as e:
        return (False, e)


def main():
    cmd = ("""./hadoop dfs -D hadoop.job.ugi='sf_public,llwGuw9mVlYuQ8y4' -D fs.default.name='hdfs://nmg01-khan-hdfs.dmop.baidu.com:54310' -ls  /app/ecom/aries/galaxy/hive_dw/risk_data.db/credit_cid_reject_count_hour/time_stamp=20151010070000""")
    (success, msg) = execute(cmd)
    print success
    print msg


if __name__ == "__main__":
    main()
