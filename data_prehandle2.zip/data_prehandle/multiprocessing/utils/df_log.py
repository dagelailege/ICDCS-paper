#!/usr/bin/env python
# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
�򵥵���־���װ�����ڼ�����ǰ��ʹ�÷�ʽ

Authors: huabo (daijun), caodaijun@baidu.com
Date: 2014/12/05 11:36:01
"""


import os
import sys
import logging
import datetime


class _DfLog(object):
    def __init__(self):
        self._logger = None

    @staticmethod
    def instance():
        """������ʵ������������ڣ��򴴽�
        """
        if not hasattr(_DfLog, "_instance"):
            _DfLog._instance = _DfLog()
        return _DfLog._instance

    @staticmethod
    def initialized():
        """������Ƿ��ѳ�ʼ��
        """
        return hasattr(_DfLog, "_instance")

    def init(self, log_file, log_level="INFO"):
        """��ʼ����־��
        Args:
            log_file ָ����־�ļ�¼�ļ�
            log_level ָ����־�ļ�¼����
        Return:
            None
        """
        level_map = {"ERR":   logging.ERROR,
                     "WARN":  logging.WARNING,
                     "INFO":  logging.INFO,
                     "DEBUG": logging.DEBUG}
        logging_level = level_map.get(log_level.upper(), logging.INFO)

        today = datetime.datetime.now().strftime('%Y%m%d')
        logging_file = "%s.%s" % (log_file, today)

        formatter = logging.Formatter("%(asctime)s %(process)d %(levelname)s: %(message)s")
        handler = logging.FileHandler(logging_file)
        handler.setFormatter(formatter)

        self._logger = logging.getLogger()
        self._logger.addHandler(handler)
        self._logger.setLevel(logging_level)

    def getlogger(self):
        """������־��ľ��
        """
        return self._logger


def _print_log(level, msg):
    now = datetime.datetime.now()
    asctime = "%s,%s" % (now.strftime("%Y-%m-%d %H:%M:%S"), now.microsecond / 1000)
    pid = os.getpid()
    print("%s %s %s: %s" % (asctime, pid, level, msg))


def _caller_info():
    """��ȡ�����ĵ�������Ϣ
    Return:
        str
    """
    import sys
    frame = sys._getframe(2)
    try:
        info = "[filename:%s, func:%s, line:%s]" % (
                frame.f_code.co_filename, frame.f_code.co_name, frame.f_lineno)
        return info
    except Exception as e:
        return "[filename:unknow, func:unknow, line:unknow]"


def init(log_file, log_level="INFO"):
    """��ʼ����־����
    Args:
        log_file ָ����־�ļ�¼�ļ�
        log_level ָ����־�ļ�¼����
    Return:
        None
    """
    _DfLog.instance().init(log_file, log_level)


def debug(msg):
    """��¼debug��־
    Args:
        msg ��־��Ϣ��
    Return:
        None
    """
    if _DfLog.initialized():
        _DfLog.instance().getlogger().debug(msg + _caller_info())
    else:
        _print_log("DEBUG", msg + _caller_info())


def info(msg):
    """��¼info��־
    Args:
        msg ��־��Ϣ��
    Return:
        None
    """
    if _DfLog.initialized():
        _DfLog.instance().getlogger().info(msg)
    else:
        _print_log("INFO", msg)


def warn(msg):
    """��¼warn��־
    Args:
        msg ��־��Ϣ��
    Return:
        None
    """
    if _DfLog.initialized():
        _DfLog.instance().getlogger().warn(msg)
    else:
        _print_log("WARNING", msg)


def err(msg):
    """��¼err��־
    Args:
        msg ��־��Ϣ��
    Return:
        None
    """
    if _DfLog.initialized():
        _DfLog.instance().getlogger().error(msg)
    else:
        _print_log("ERROR", msg)


if __name__ == "__main__":
    debug("debug message.")
    info("info message.")
    warn("warn message.")
    err("err message.")
    init("log_unittest.log", "INFO")
    debug("debug message to log file.")
    info("info message to log file.")
    warn("warn message to log file.")
    err("err message to log file.")
