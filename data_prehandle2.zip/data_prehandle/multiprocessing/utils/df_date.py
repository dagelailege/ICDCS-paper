#!/usr/bin/env python
# -*- coding: utf-8 -*-
################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
封装常用的日期函数

Authors: huabo (daijun), caodaijun@baidu.com
Date: 2014/12/05 11:48:55
"""


import re
import time
import datetime


def now(formatter="%Y-%m-%d %H:%M:%S"):
    """获取当前时间，以指定格式返回
    Args:
        formatter 字符串形式的日期时间格式
    Return:
        string
    """
    return datetime.datetime.now().strftime(formatter)


def today(formatter="%Y%m%d"):
    """获取当天的日期，以指定格式返回
    Args:
        formatter 字符串形式的日期格式
    Return:
        string
    """
    return now(formatter)


def format_string(date_str=None, pre_formatter="%Y%m%d", new_formatter="%Y%m%d000000"):
    """日期格式转换，将日期字符串转换为指定格式
    Args:
        date_str: 日期字符串
        pre_formatter: 原日期字符串的格式
        new_formatter: 新日期字符串的格式
    Return:
        string
    """
    date_date = datetime.datetime.strptime(date_str, pre_formatter)
    date_new = datetime.datetime.strftime(date_date, new_formatter)
    return date_new


def date_hour(offset=0, formatter="%Y%m%d%H"):
    """计算距离当前日期之前（之后）的日期
    Args:
        offset: 日期偏移量
        formatter: 日期格式
    Returns:
        string
    """
    cur_date = datetime.datetime.now()
    new_date = cur_date + datetime.timedelta(hours = offset)
    return new_date.strftime(formatter)


def timestamp(time_str=None, time_format=None):
    """将指定的日期时间，转换成UNIX时间戳
    Args:
        time_str 字符串形式的日期时间
        time_format 指定time_str的日期时间格式
        如果time_str或time_format任何一个值为None，则返回当前的时间戳
    Return:
        int
    """
    if time_str is None or time_format is None:
        return int(time.time())
    else:
        return int(time.mktime(time.strptime(time_str, time_format)))


def daysfrom(time_str, time_format):
    """计算指定时间到当天的间隔天数
    Args:
        time_str 字符串形式的日期时间
        time_format 指定time_str的日期时间格式
    Return:
        int
    """
    temp = timestamp(time_str, time_format)
    now = timestamp()
    return int((now - temp) / 86400)


def _gen_date(format_str="Ymd", offset=None, frequency=None, stamp=None):
    format_str = format_str.replace("Y", "%Y")
    format_str = format_str.replace("m", "%m")
    format_str = format_str.replace("d", "%d")
    format_str = format_str.replace("H", "%H")
    format_str = format_str.replace("h", "%h")
    format_str = format_str.replace("M", "%M")
    format_str = format_str.replace("S", "%S")

    offset_num = 0
    if offset is not None:
        offset_unit = 0
        if offset[-1:].upper() == "D":
            offset_unit = 60 * 60 * 24
        elif offset[-1:].upper() == "H":
            offset_unit = 60 * 60
        elif offset[-1:].upper() == "M":
            offset_unit = 60

        try:
            offset = offset[0:-1]
            offset_num = int(offset) * offset_unit
        except ValueError as e:
            pass

    temp = stamp
    if temp is None:
        temp = timestamp()

    frequency_offset = 0
    frequency_offset_num = 0
    if frequency is not None:
        if frequency.upper() == "MONTH":
            frequency_offset = time.strftime("%d", time.localtime(temp))
            frequency_offset_num = (int(frequency_offset) - 1) * 60 * 60 * 24
        elif frequency.upper() == "WEEK":
            frequency_offset = time.strftime("%w", time.localtime(temp))
            frequency_offset_num = (int(frequency_offset) - 1) * 60 * 60 * 24
        elif frequency.upper() == "HALFHOUR":
            frequency_offset_num = temp % (30 * 60)

    temp = temp - frequency_offset_num + offset_num
    return time.strftime(format_str, time.localtime(temp))


def format(date_str, stamp=None):
    """格式化时间描述字符串
    Args:
        date_str 形如adfa${date format='Ymd/HM' offset='-10M' frequency='week'}xxx格式的描述
        stamp 指定时间戳
    Return:
        string 指定格式的日期时间字符串
    """
    if date_str is None:
        return ""

    while True:
        token = None
        token_re = re.search(r"""\${date [^}]*}""", date_str)
        if token_re is not None:
            token = token_re.group(0)
        if token is None:
            break

        date_format = None
        format_re = re.search(r"""format *= *(['"])([/YmdHhMS0]*)\1""", token)
        if format_re is not None:
            date_format = format_re.group(2)
        if date_format is None:
            break

        date_offset = None
        offset_re = re.search(r"""offset *= *(['"])([\-0-9dDhHmM]*)\1""", token)
        if offset_re is not None: 
            date_offset = offset_re.group(2)

        date_frequency = None
        frequency_re = re.search(r"""frequency *= *(['"])([a-zA-Z]*)\1""", token)
        if frequency_re is not None:
            date_frequency = frequency_re.group(2)

        date_value = _gen_date(date_format, date_offset, date_frequency, stamp=stamp)
        date_str = date_str.replace(token, date_value)
    return date_str


def format_by_unit(unit):
    """格式化时间描述字符串，是对format的简单封装，参数更直观
    Args:
        unit 指定计算时间的单元，支持day, hour, halfhour
    Return:
        string 指定格式的日期时间字符串
    """
    if unit is None:
        return ""

    unit = unit.lower()
    if unit not in ["day", "hour", "halfhour"]:
        return ""

    date_desc = None
    if unit == "day":
        date_desc = "${date format='Ymd'}"
    if unit == "hour":
        date_desc = "${date format='YmdHM00' frequency='hour'}"
    if unit == "halfhour":
        date_desc = "${date format='YmdHM00' frequency='halfHour'}"
    if date_desc is None:
        return ""

    return format(date_desc)
    

if __name__ == "__main__":
    print now()
    print timestamp()
    print timestamp("2014-10-10", "%Y-%m-%d")
    print format("/home/work/${date format='Ymd'}")
    print format("/home/work/${date format='Ymd' offset='-1d'}")
    print format("/home/work/${date format='Ymd' offset='-2d'}")
    print format("/home/work/${date format='Ymd' offset='-1d' frequency='week'}")
    print format("/home/work/${date format='Ymd/HM'}")
    print format("/home/work/${date format='Ymd/HM' frequency='halfHour'}")
    print format("/home/work/${date format='Ymd/HM' offset='-10M' frequency='halfHour'}")
    print format_by_unit("notsupport")
    print format_by_unit("day")
    print format_by_unit("halfhour")

    print format("/home/work/${date format='Ymd' offset='-1d'}")
    print format("/home/work/${date format='YmdH0000' offset='-2H' frequence='hour'}")
    print format_string("20151012", "%Y%m%d", "%Y%m%d000000")
    print now(formatter="%H0000")
    print date_hour(offset = -1, formatter='%H0000') 
