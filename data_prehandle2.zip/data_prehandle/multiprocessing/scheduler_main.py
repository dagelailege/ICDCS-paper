import multiprocessing
from multiprocessing.pool import ThreadPool
from utils import df_log as log
import time
import datetime
import subprocess

g_subprocess_py = "d:/python_lib/optimize.py"
g_detect_worker_finish_interval = 60

class WorkerOnSubprocess(object):
    """WorkerOnSubprocess
    """
    def __init__(self, target=None, mainpy=None, args=None):
        """

        """
        if (args is None):
            args = ()
        self.cmd = "python " + mainpy + " "
        for arg in args:
            self.cmd += str(arg) + " "

    def start(self):
        """start
        """
        #print ("start cmd {}".format(self.cmd))
        log.info("Start subprocess by cmd:{}".format(self.cmd))
        self.alive = False
        try:
            self.p = subprocess.Popen(self.cmd, shell=True)
            log.info("Start subprocess success.")
        except Exception as ex:
            log.err("Start subprocess start error, exception: {}".format(str(ex)))
        self.alive = True

    def join(self, timeout):
        """join
        """
        time.sleep(timeout)

    def is_alive(self):
        """is_alive
        """
        try:
            if (self.alive == True):
                ret = self.p.poll()
                self.alive = ret is None
        except Exception as e:
            log.err("Poll exception")
        return self.alive

    def terminate(self):
        """terminate
        """
        if (self.is_alive()):
            try:
                self.p.terminate()
            except Exception as e:
                log.err("Fail to terminate. cmd:{}".format(self.cmd))
        log.info("Terminate subprocess. cmd:{}".format(self.cmd))
class schedulerMain(object):
    """
    main downloader
    """
    def __init__(self):
        self.log_dir = "./log"
        self.free_wait_time = 30
        self.loop_wait_time = 30
        self.max_loader_process = 12
        self.cur_loader_process = 0
        self.worker_pool = ThreadPool(self.max_loader_process)
        log.init("%s/download.log" % self.log_dir)
    def _worker_monitor_thread_func(self, task_id,task_date):
        #subproccess_id = "{}_{}".format(optype, arg_file_name)
        #print ("into worker_monitor_thread_func")
        subproccess_id = task_id
        log.info("into worker_monitor_thread_func")
        log.info("Spawn a new thread to handle. subproccess_id:{}".format(subproccess_id))
        try:
            mainpy = g_subprocess_py
            p = WorkerOnSubprocess(target=None,
                                   mainpy=mainpy,
                                   args=(task_id,task_date,))
            p.start()
            while (True):
                p.join(g_detect_worker_finish_interval)
                if (not p.is_alive()):
                    break
        except Exception as e:
            log.err("Failed to handle subproccess_id:{}".format(
                    subproccess_id))
        log.info("Finish spawn a new file to handle.subproccess_id:{}".format(
                    subproccess_id))
    def loader_finish(self, func_ret):
        """loader finish method
        """
        print ("finish a task!")
        self.cur_loader_process -= 1
        pass
    def task_process(self,task_id,task_date):
        """raise a subprocess to load file
        """
        finishcb = self.loader_finish
        result = self.worker_pool.apply_async(self._worker_monitor_thread_func,args=(task_id,task_date,),callback=finishcb)
        self.cur_loader_process += 1
if __name__ == "__main__":
    dates = ["26"]
    for date in dates:
        i = 0
        schedulermain = schedulerMain()
        while (True):
            remain_resource = schedulermain.max_loader_process - schedulermain.cur_loader_process
            if(remain_resource<=0):
                print "No available resource. sleep..."
                time.sleep(float(schedulermain.free_wait_time))
                continue
            if i < 72:
                schedulermain.task_process(i,date)
                print ("begin task {}".format(i))
                i+=1
            else:
                if remain_resource == 11:
                    break
        del schedulermain
        
        
    