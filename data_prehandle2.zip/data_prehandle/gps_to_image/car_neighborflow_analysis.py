import pymongo
import dateutil.parser
import codecs
import re
from time import time
import os
import pandas as pd
import numpy as np
import math
import smopy
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import copy
from math import radians, cos, sin, asin, sqrt

"""
根据经纬度获取距离
参数分别是：精度1，精度2，纬度1，纬度2
"""
def get_distance(_lng1,_lng2,_lat1,_lat2):
    _lng1 = _lng1/100000
    _lng2 = _lng2/100000
    _lat1 = _lat1/100000
    _lat2 = _lat2/100000
    lng1, lat1, lng2, lat2 = map(radians, [_lng1, _lat1, _lng2, _lat2])
    dlon=lng2-lng1
    dlat=lat2-lat1
    a=sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    distance=2*asin(sqrt(a))*6371*1000
    #print (distance)
    return distance

#get_distance(165.112,167.562,39.221,38.456)


client = pymongo.MongoClient("localhost",27017)
db = client.vnetdata
taxi_table = db.taxi_15
bus_table =db.bus_15
xl_table = db.xl_15
#每五分钟画一张图片
#北京四环经纬度
#左上：39.9866,116.2652 右上：39.9866,116.4839   左下：39.8270,116.2652    右下：39.8270,116.4839
#纬度start:39.9866    end:39.8270    方向：从上到下，从大到小    分40个格子split:0.00399
#精度start:116.2652     end:116.4838      方向：从左到右，小到大   分40个格子split:0.005465
start_time = 1475164800 #20160930 00:00:00转化为UNIX时间戳,单位是秒   28466
split = 120
max_latitude = 39.9966*100000
max_longitude = 116.4939*100000
min_latitude = 39.8270*100000
min_longitude = 116.2652*100000
shf_path1 = 'F:/gradute_student_2017/Vnet/ICDCS/bj_shp/高速公路s_polyline'
shf_path2 = 'F:/gradute_student_2017/Vnet/ICDCS/bj_shp/市区道路_polyline'
cmap = plt.get_cmap('RdYlGn_r')
region_acc = 40        #划分为个region_acc*region_acc个格子

offset = 0
lat_split = (max_latitude-min_latitude)/region_acc
lon_split = (max_longitude-min_longitude)/region_acc
#car_left_id = set()
#car_mid_id = set()
#car_right_id = set()
#fig = plt.figure(figsize=(12,8))
"""
获取所有车所有时刻的速度：
"""



for slot in range(offset+0,721):
    left = start_time + (slot)*split
    right = left + split
    #print (right)
    if slot==offset+0:
        ##获取本时刻所有的在四环内的车辆的数据
        car_left_regions_id = {}       #key为区域的编号，value为这个区域的车辆id组成的set()
        car_right_regions_id = {}       #同上
        car_left_point_dict = {}        #key为car_id,第二维key为时刻，value为第一次出现的经纬度和时间
        car_right_point_dict = {}        #同上
        taxis_left = taxi_table.find({'time':{"$gte":str(left),"$lt":str(right)},'longitude':{"$gt":str(min_longitude),"$lt":str(max_longitude)},'latitude':{"$gt":str(min_latitude),"$lt":str(max_latitude)}})
        taxis_left_list = list(taxis_left)
        taxis_left_df = pd.DataFrame(taxis_left_list)
        buses_left = bus_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        buses_left_list = list(buses_left)
        buses_left_df = pd.DataFrame(buses_left_list)
        xls_left = xl_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        xls_left_list = list(xls_left)
        xls_left_df = pd.DataFrame(xls_left_list)
        car_left_df = pd.concat([taxis_left_df,buses_left_df,xls_left_df],ignore_index=True)
        #print (car_left_df.head(2))
        #计算每辆车是属于哪个小格子，形成一个dict,key:行，列   value:这个格子里的车辆的id集合row[1]:car_id,row[2]:lat,row[3]:lon
        for row in car_left_df.iterrows():                #row[1][1] car_id row[1][2] lat  row[1][3] lon row[1][4] time
            lat = float(row[1][2])
            lon = float(row[1][3])
            row_id = math.floor((max_latitude-lat)/lat_split)
            col_id = math.floor((lon-min_longitude)/lon_split)
            key = str(row_id)+","+str(col_id)
            if key not in car_left_regions_id:
                car_left_regions_id[key] = set()
            car_left_regions_id[key].add(row[1][1])
            if row[1][1] not in car_left_point_dict:
                car_left_point_dict[row[1][1]] = row[1]
        print ("get_left")
        continue
    if slot >=offset+1:
        if slot>=offset+2:
            car_left_regions_id = copy.deepcopy(car_right_regions_id)
            car_right_regions_id.clear()
            car_left_df = copy.deepcopy(car_right_df)
            car_left_point_dict = copy.deepcopy(car_right_point_dict)
            car_right_point_dict.clear()
        #start = time()
        taxis_right = taxi_table.find({'time':{"$gte":str(left),"$lt":str(right)},'longitude':{"$gt":str(min_longitude),"$lt":str(max_longitude)},'latitude':{"$gt":str(min_latitude),"$lt":str(max_latitude)}})
        taxis_right_list = list(taxis_right)
        taxis_right_df = pd.DataFrame(taxis_right_list)
        buses_right = bus_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        buses_right_list = list(buses_right)
        buses_right_df = pd.DataFrame(buses_right_list)
        xls_right = xl_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        xls_right_list = list(xls_right)
        xls_right_df = pd.DataFrame(xls_right_list)
        car_right_df = pd.concat([taxis_right_df,buses_right_df,xls_right_df],ignore_index=True)
        for row in car_right_df.iterrows():
            lat = float(row[1][2])
            lon = float(row[1][3])
            row_id = math.floor((max_latitude-lat)/lat_split)
            col_id = math.floor((lon-min_longitude)/lon_split)
            key = str(row_id)+","+str(col_id)
            if key not in car_right_regions_id:
                car_right_regions_id[key] = set()
            car_right_regions_id[key].add(row[1][1])
            if row[1][1] not in car_right_point_dict:
                car_right_point_dict[row[1][1]] = row[1]
        print ("get_right")
    #car_left_regions_df = pd.DataFrame(car_left_regions_id["33,23"]) 把某个区域的车辆list转换为dataframe便于后续计算
    #car_left_df.to_csv("car_left_df.csv",index=False)
    #car_mid_df.to_csv("car_mid_df.csv",index=False)
    #car_right_df.to_csv("car_right_df.csv",index=False)
    car_out_flow = np.zeros((region_acc,region_acc,8,2))    #四个维度分别代表的是格子的行，列，4个邻居(0左1上2右3下)，数量和平均速度
    total_car_out = np.zeros((region_acc,region_acc))
    for i in range(region_acc):
        for j in range(region_acc):
            index = str(i)+","+str(j)
            #这个区域没有车，四个邻居的流出量和流出速度都为0
            if index not in car_left_regions_id:
                car_out_flow[region_acc-i-1][j][0][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][0][1]=0       #速度为0
                car_out_flow[region_acc-i-1][j][1][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][1][1]=0       #速度为0
                car_out_flow[region_acc-i-1][j][2][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][2][1]=0       #速度为0
                car_out_flow[region_acc-i-1][j][3][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][3][1]=0       #速度为0
                continue
            #选出时间最近的点
            #car_left_id_df = pd.DataFrame(car_left_regions_id[index]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
            #所有格子里的车的id的set
            #car_left_carid = set(car_left_id_df['car_id'].values)
            car_left_carid = car_left_regions_id[index]
            #计算左边的格子
            index_left = str(i)+","+str(j-1)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_left not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][0][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][0][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点,保证车辆的唯一性
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_left]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_left]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][0][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][0][1]=0       #速度为0
                else:
                    car_out_flow[region_acc-i-1][j][0][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][0][1]= total_speed/car_out_flow[region_acc-i-1][j][0][0]
                    #print (car_out_flow[region_acc-i-1][j][0][1])
            #计算上边的格子
            index_top = str(i-1)+","+str(j)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_top not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][1][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][1][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_top]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_top]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][1][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][1][1]=0       #速度为0
                else:
                    car_out_flow[region_acc-i-1][j][1][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][1][1]= total_speed/car_out_flow[region_acc-i-1][j][1][0]
                    #print (car_out_flow[region_acc-i-1][j][1][1])
            #计算右边的格子
            index_right = str(i)+","+str(j+1)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_right not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][2][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][2][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_right]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_right]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][2][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][2][1]=0       #速度为0
                else:
                #print (union_car_id)
                #exit()
                    car_out_flow[region_acc-i-1][j][2][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][2][1]= total_speed/car_out_flow[region_acc-i-1][j][2][0]
                    #print (car_out_flow[region_acc-i-1][j][2][1])
            #计算下边的格子
            index_bottom = str(i+1)+","+str(j)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_bottom not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][3][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][3][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_bottom]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_bottom]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][3][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][3][1]=0       #速度为0
                else:
                #print (union_car_id)
                #exit()
                    car_out_flow[region_acc-i-1][j][3][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][3][1]= total_speed/car_out_flow[region_acc-i-1][j][3][0]
            #计算左上的格子
            index_lt = str(i-1)+","+str(j-1)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_lt not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][4][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][4][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_bottom]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_lt]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][4][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][4][1]=0       #速度为0
                else:
                #print (union_car_id)
                #exit()
                    car_out_flow[region_acc-i-1][j][4][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][4][1]= total_speed/car_out_flow[region_acc-i-1][j][4][0]
            #计算左下的格子
            index_lb = str(i+1)+","+str(j-1)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_lb not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][5][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][5][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_bottom]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_lb]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][5][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][5][1]=0       #速度为0
                else:
                #print (union_car_id)
                #exit()
                    car_out_flow[region_acc-i-1][j][5][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][5][1]= total_speed/car_out_flow[region_acc-i-1][j][5][0]
            #计算右上的格子
            index_rt = str(i-1)+","+str(j+1)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_rt not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][6][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][6][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_bottom]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_rt]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][6][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][6][1]=0       #速度为0
                else:
                #print (union_car_id)
                #exit()
                    car_out_flow[region_acc-i-1][j][6][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][6][1]= total_speed/car_out_flow[region_acc-i-1][j][6][0]
            #计算右下的格子
            index_rb = str(i+1)+","+str(j+1)
            #这个区域没车，这个邻居流出量和流出速度都为0
            if index_rb not in car_right_regions_id:
                car_out_flow[region_acc-i-1][j][7][0]=0       #数量为0
                car_out_flow[region_acc-i-1][j][7][1]=0       #速度为0
            #这个区域有车
            else:
                #选出时间最近的点
                #car_right_id_df = pd.DataFrame(car_right_regions_id[index_bottom]).groupby('car_id',group_keys=False).apply(lambda t:t[t.time == t.time.min()])
                #union_car_id = car_left_id_df.merge(car_right_id_df,on="car_id")
                #car_right_carid = set(car_right_id_df['car_id'].values)
                car_right_carid = car_right_regions_id[index_rb]
                union_car_id = car_left_carid&car_right_carid
                #print (union_car_id)
                if len(union_car_id)==0:
                    car_out_flow[region_acc-i-1][j][7][0]=0       #数量为0
                    car_out_flow[region_acc-i-1][j][7][1]=0       #速度为0
                else:
                #print (union_car_id)
                #exit()
                    car_out_flow[region_acc-i-1][j][7][0]= len(union_car_id)    #数量，这个时刻在本格子，下个时刻在左边的格子里，这两个时刻的格子求交集
                #计算交集中每个车辆的速度
                    total_speed = 0
                    for car_id in union_car_id:
                        time_x = car_left_point_dict[car_id][4]
                        time_y = car_right_point_dict[car_id][4]
                        lon_x = car_left_point_dict[car_id][3]
                        lon_y = car_right_point_dict[car_id][3]
                        lat_x = car_left_point_dict[car_id][2]
                        lat_y = car_right_point_dict[car_id][2]
                        try:
                            total_speed += get_distance(float(lon_x),float(lon_y),float(lat_x),float(lat_y))/(float(time_y)-float(time_x))
                        except:
                            continue
                    car_out_flow[region_acc-i-1][j][7][1]= total_speed/car_out_flow[region_acc-i-1][j][7][0]
                    #print (car_out_flow[region_acc-i-1][j][3][1])
            #total_car_out[region_acc-i-1][j] = car_out_flow[region_acc-i-1][j][0][0]+car_out_flow[region_acc-i-1][j][1][0]+car_out_flow[region_acc-i-1][j][2][0]+car_out_flow[region_acc-i-1][j][3][0]
            #print (len(car_left_id),len(car_mid_id),len(car_right_id))
    #print (car_left_regions_id)
    #np.save("/home/luoguiyang/wuzhiheng/car_flow_np_20160902/{}_in_flow_new.npy".format(slot-1),car_in_flow)
    #print (total_car_out.max())
    car_out_flow.reshape((region_acc*region_acc*8*2,1))
    print (car_out_flow.max())
    np.save("./car_nflow_np_20160930/{}_out_nflow.npy".format(slot-1),car_out_flow)

    #print (car_flow_re.max())
    #print ("get np OK!")
    """
    fig = plt.figure(figsize=(12,8))
    m = Basemap(llcrnrlon=min_longitude/100000, llcrnrlat=min_latitude/100000, urcrnrlon=max_longitude/100000, urcrnrlat=max_latitude/100000,projection='stere',lat_0=min_latitude/100000,lon_0=min_longitude/100000)
    #readshapefile耗费大量的时间
    m.readshapefile(shf_path1,'roads',color='black',linewidth =1)
    m.readshapefile(shf_path2,'roads',color = 'black')
    lons, lats, x, y = m.makegrid(region_acc, region_acc, returnxy=True)
    #print (lons[0][0],lats[0][0])
    cs = m.contourf(x,y,car_in_flow)
    cs.set_cmap(cmap)
    cbar = m.colorbar(cs,location='bottom',pad="5%")
    cbar.set_label('car_in_flow')
    plt.savefig('F:/gradute_student_2017/Vnet/ICDCS/data_pre_handle/car_flow_image/{}_in_flow_new.png'.format(slot-1))
    m = Basemap(llcrnrlon=min_longitude/100000, llcrnrlat=min_latitude/100000, urcrnrlon=max_longitude/100000, urcrnrlat=max_latitude/100000,projection='stere',lat_0=min_latitude/100000,lon_0=min_longitude/100000)
    m.readshapefile(shf_path1,'roads',color='black',linewidth =1)
    m.readshapefile(shf_path2,'roads',color = 'black')
    lons, lats, x, y = m.makegrid(region_acc, region_acc, returnxy=True)
    #print (lons[0][0],lats[0][0])
    cs = m.contourf(x,y,car_out_flow)
    cs.set_cmap(cmap)
    cbar = m.colorbar(cs,location='bottom',pad="5%")
    cbar.set_label('car_out_flow')
    plt.savefig('F:/gradute_student_2017/Vnet/ICDCS/data_pre_handle/car_flow_image/{}_out_flow_new.png'.format(slot-1))
    plt.close('all')
    """
    print ("finished {}".format(slot-1))
