import pymongo
import dateutil.parser
import codecs
import re
from time import time
import os
import pandas as pd
import numpy as np
import math
import smopy
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import copy

client = pymongo.MongoClient("localhost",27017)
db = client.vnetdata
taxi_table = db.taxi_15
bus_table =db.bus_15
xl_table = db.xl_15
#每五分钟画一张图片
#北京四环经纬度
#左上：39.9866,116.2652 右上：39.9866,116.4839   左下：39.8270,116.2652    右下：39.8270,116.4839
#纬度start:39.9866    end:39.8270    方向：从上到下，从大到小    分40个格子split:0.00399
#精度start:116.2652     end:116.4838      方向：从左到右，小到大   分40个格子split:0.005465
start_time = 1475164800 #20160930 00:00:00转化为UNIX时间戳,单位是秒   28466
split = 120
max_latitude = 39.9966*100000
max_longitude = 116.4939*100000
min_latitude = 39.8270*100000
min_longitude = 116.2652*100000
shf_path1 = 'F:/gradute_student_2017/Vnet/ICDCS/bj_shp/高速公路s_polyline'
shf_path2 = 'F:/gradute_student_2017/Vnet/ICDCS/bj_shp/市区道路_polyline'
cmap = plt.get_cmap('RdYlGn_r')
region_acc = 40        #划分为个region_acc*region_acc个格子

offset = 0
lat_split = (max_latitude-min_latitude)/region_acc
lon_split = (max_longitude-min_longitude)/region_acc
#car_left_id = set()
#car_mid_id = set()
#car_right_id = set()
#fig = plt.figure(figsize=(12,8))
for slot in range(offset+0,721):
    left = start_time + (slot)*split
    right = left + split
    if slot==offset+0:
        car_left_regions_id = {}
        car_mid_regions_id = {}
        car_right_regions_id = {}
        taxis_left = taxi_table.find({'time':{"$gte":str(left),"$lt":str(right)},'longitude':{"$gt":str(min_longitude),"$lt":str(max_longitude)},'latitude':{"$gt":str(min_latitude),"$lt":str(max_latitude)}})
        taxis_left_list = list(taxis_left)
        taxis_left_df = pd.DataFrame(taxis_left_list)
        buses_left = bus_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        buses_left_list = list(buses_left)
        buses_left_df = pd.DataFrame(buses_left_list)
        xls_left = xl_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        xls_left_list = list(xls_left)
        xls_left_df = pd.DataFrame(xls_left_list)
        car_left_df = pd.concat([taxis_left_df,buses_left_df,xls_left_df],ignore_index=True)
        #print (car_left_df.head(2))
        for row in car_left_df.iterrows():
            lat = float(row[1][2])
            lon = float(row[1][3])
            row_id = math.floor((max_latitude-lat)/lat_split)
            col_id = math.floor((lon-min_longitude)/lon_split)
            key = str(row_id)+","+str(col_id)
            if key not in car_left_regions_id:
                car_left_regions_id[key] = set()
            car_left_regions_id[key].add(row[1][1])
        print ("get_left")
        continue
    if slot >=offset+1:
        if slot>offset+1:
            car_left_regions_id = copy.deepcopy(car_right_regions_id)
            car_right_regions_id.clear()
        #start = time()
        taxis_right = taxi_table.find({'time':{"$gte":str(left),"$lt":str(right)},'longitude':{"$gt":str(min_longitude),"$lt":str(max_longitude)},'latitude':{"$gt":str(min_latitude),"$lt":str(max_latitude)}})
        taxis_right_list = list(taxis_right)
        taxis_right_df = pd.DataFrame(taxis_right_list)
        buses_right = bus_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        buses_right_list = list(buses_right)
        buses_right_df = pd.DataFrame(buses_right_list)
        xls_right = xl_table.find({'time':{"$gte":left,"$lt":right},'longitude':{"$gt":min_longitude,"$lt":max_longitude},'latitude':{"$gt":min_latitude,"$lt":max_latitude}})
        xls_right_list = list(xls_right)
        xls_right_df = pd.DataFrame(xls_right_list)
        car_right_df = pd.concat([taxis_right_df,buses_right_df,xls_right_df],ignore_index=True)
        for row in car_right_df.iterrows():
            lat = float(row[1][2])
            lon = float(row[1][3])
            row_id = math.floor((max_latitude-lat)/lat_split)
            col_id = math.floor((lon-min_longitude)/lon_split)
            key = str(row_id)+","+str(col_id)
            if key not in car_right_regions_id:
                car_right_regions_id[key] = set()
            car_right_regions_id[key].add(row[1][1])
        print ("get_right")
    #car_left_df.to_csv("car_left_df.csv",index=False)
    #car_mid_df.to_csv("car_mid_df.csv",index=False)
    #car_right_df.to_csv("car_right_df.csv",index=False)
    car_in_flow = np.zeros((region_acc,region_acc))
    car_out_flow = np.zeros((region_acc,region_acc))
    for i in range(region_acc):
        for j in range(region_acc):
            car_right_id = car_right_regions_id.setdefault((str(i)+","+str(j)),set())
            car_left_id = car_left_regions_id.setdefault((str(i)+","+str(j)),set())
            inflow = len(car_right_id - car_left_id)
            outflow = len(car_left_id - car_right_id)
            """
            if i>5 and i<36 and j>5 and j<36 and outflow >=10:
                print (car_left_id - car_right_id)
                print (left,right,i,j)
                exit()
            """
            car_in_flow[region_acc-i-1][j] = inflow
            car_out_flow[region_acc-i-1][j] = outflow
            #print (len(car_left_id),len(car_mid_id),len(car_right_id))
    #print (car_in_flow.max())
    #print (car_out_flow.max())
    #exit()
    np.save("./car_flow_np_20160930/{}_in_flow.npy".format(slot-1),car_in_flow)
    np.save("./car_flow_np_20160930/{}_out_flow.npy".format(slot-1),car_out_flow)
    #print (car_flow_re.max())
    #print ("get np OK!")
    """
    fig = plt.figure(figsize=(12,8))
    m = Basemap(llcrnrlon=min_longitude/100000, llcrnrlat=min_latitude/100000, urcrnrlon=max_longitude/100000, urcrnrlat=max_latitude/100000,projection='stere',lat_0=min_latitude/100000,lon_0=min_longitude/100000)
    #readshapefile耗费大量的时间
    m.readshapefile(shf_path1,'roads',color='black',linewidth =1)
    m.readshapefile(shf_path2,'roads',color = 'black')
    lons, lats, x, y = m.makegrid(region_acc, region_acc, returnxy=True)
    #print (lons[0][0],lats[0][0])
    cs = m.contourf(x,y,car_in_flow)
    cs.set_cmap(cmap)
    cbar = m.colorbar(cs,location='bottom',pad="5%")
    cbar.set_label('car_in_flow')
    plt.savefig('F:/gradute_student_2017/Vnet/ICDCS/data_pre_handle/car_flow_image/{}_in_flow_new.png'.format(slot-1))
    m = Basemap(llcrnrlon=min_longitude/100000, llcrnrlat=min_latitude/100000, urcrnrlon=max_longitude/100000, urcrnrlat=max_latitude/100000,projection='stere',lat_0=min_latitude/100000,lon_0=min_longitude/100000)
    m.readshapefile(shf_path1,'roads',color='black',linewidth =1)
    m.readshapefile(shf_path2,'roads',color = 'black')
    lons, lats, x, y = m.makegrid(region_acc, region_acc, returnxy=True)
    #print (lons[0][0],lats[0][0])
    cs = m.contourf(x,y,car_out_flow)
    cs.set_cmap(cmap)
    cbar = m.colorbar(cs,location='bottom',pad="5%")
    cbar.set_label('car_out_flow')
    plt.savefig('F:/gradute_student_2017/Vnet/ICDCS/data_pre_handle/car_flow_image/{}_out_flow_new.png'.format(slot-1))
    plt.close('all')
    """
    print ("finished {}".format(slot-1))
