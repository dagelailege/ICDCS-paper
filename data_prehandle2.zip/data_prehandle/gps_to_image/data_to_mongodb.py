import pymongo
import dateutil.parser
import codecs
import re
import time
import os

#读取出租车数据并导入到mongodb
taxi_file = "F:/gradute_student_2017/Vnet/ICDCS/data/taxi/201609/20160930/20160930.txt"
data = []
i=0
client = pymongo.MongoClient("localhost", 27017)
db = client.vnetdata
taxi_table = db.taxi_15
print ("taxi data start insert into mongodb")
with codecs.open(taxi_file, 'r','utf-8') as f:
    for line in f:
        i+=1
        row = {}
        try:
            columns = line.split('\t')
            row['car_id'] = columns[1]
            row['time'] = columns[2]
            row['latitude'] = columns[4]
            row['longitude'] = columns[5]
            data.append(row)
        except:
            continue
        if i%500000==0:
            #导入进mongodb
            taxi_table.insert_many(data)
            data = []
            print ("finished:{}".format(i))
num = taxi_table.count()
print ("taxi_data has into mongodb,total insert:{}".format(num))
"""
"""
#bus数据导入mongodb
bus_base_path  = "F:/gradute_student_2017/Vnet/ICDCS/data/bus/bus/2016-09-30"
i = 0
client = pymongo.MongoClient("localhost", 27017)
db = client.vnetdata
bus_table = db.bus_15
files = os.listdir(bus_base_path)
total = len(files)
for _file in os.listdir(bus_base_path):
    i+=1
    if not re.search('BAIBUS',_file):
        path = os.path.join(bus_base_path, _file)
        if not os.path.isdir(path):
            with codecs.open(path,'r','utf-8') as f:
                data = []
                #print (path)
                for line in f.readlines():
                    row = {}
                    columns = line.split(',')
                    #print (columns[5])
                    #print (path)
                    try:
                        row['car_id'] = columns[1]
                        _time = int(time.mktime(time.strptime(columns[5], "%Y-%m-%d %H:%M:%S")))
                        row['time'] = _time       #转化为Unix时间戳
                        row['longitude'] = float(columns[6])*100000
                        row['latitude'] = float(columns[7])*100000
                        data.append(row)
                    except:
                        continue
                #print (path)
                if len(data) !=0:
                    bus_table.insert_many(data)
    if i%100==0:
        print ("finished:{} total:{}".format(i,total))
print ("bus_data has into mongodb,total insert:{}".format(bus_table.count()))
#XL数据导入mongodb
xl_base_path = "F:/gradute_student_2017/Vnet/ICDCS/data/bus/xl/20160930"
i = 0
client = pymongo.MongoClient("localhost", 27017)
db = client.vnetdata
xl_table = db.xl_15
files = os.listdir(xl_base_path)
total = len(files)
for _file in os.listdir(xl_base_path):
    i+=1
    path = os.path.join(xl_base_path, _file)
    if not os.path.isdir(path):
        with codecs.open(path,'r','utf-8') as f:
            data = []
            for line in f.readlines():
                row = {}
                columns =  line.split(',')
                try:
                    row['car_id'] = columns[1]
                    _time = int(time.mktime(time.strptime(columns[5], "%Y-%m-%d %H:%M:%S")))
                    row['time'] = _time
                    row['longitude'] = float(columns[6])*100000
                    row['latitude'] = float(columns[7])*100000
                    data.append(row)
                except:
                    continue
            if len(data) !=0:
                xl_table.insert_many(data)
    if i%50 == 0:
        print ("finished:{} total:{}".format(i,total))
